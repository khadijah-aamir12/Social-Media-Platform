import { users, posts, comments, likes, follows, type User, type InsertUser, type Post, type InsertPost, type Comment, type InsertComment, type Like, type InsertLike, type Follow, type InsertFollow } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, or, count, inArray } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  searchUsers(query: string): Promise<User[]>;

  // Post operations
  createPost(post: InsertPost, authorId: number): Promise<Post>;
  getPost(id: number): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number): Promise<Post[]>;
  getPostsByUser(userId: number, limit?: number, offset?: number): Promise<Post[]>;
  getFeedPosts(userId: number, limit?: number, offset?: number): Promise<Post[]>;
  deletePost(id: number, authorId: number): Promise<boolean>;

  // Comment operations
  createComment(comment: InsertComment, authorId: number): Promise<Comment>;
  getCommentsByPost(postId: number): Promise<Comment[]>;
  deleteComment(id: number, authorId: number): Promise<boolean>;

  // Like operations
  toggleLike(postId: number, userId: number): Promise<boolean>;
  isPostLiked(postId: number, userId: number): Promise<boolean>;
  getPostLikes(postId: number): Promise<number>;

  // Follow operations
  followUser(followerId: number, followingId: number): Promise<boolean>;
  unfollowUser(followerId: number, followingId: number): Promise<boolean>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;
  getFollowersCount(userId: number): Promise<number>;
  getFollowingCount(userId: number): Promise<number>;
  getSuggestedUsers(userId: number, limit?: number): Promise<User[]>;

  // Session store
  sessionStore: session.SessionStore;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set(userData).where(eq(users.id, id)).returning();
    return user || undefined;
  }

  async searchUsers(query: string): Promise<User[]> {
    return await db.select().from(users).where(
      or(
        sql`${users.username} ILIKE ${'%' + query + '%'}`,
        sql`${users.name} ILIKE ${'%' + query + '%'}`
      )
    ).limit(10);
  }

  // Post operations
  async createPost(post: InsertPost, authorId: number): Promise<Post> {
    const [newPost] = await db.insert(posts).values({ ...post, authorId }).returning();
    return newPost;
  }

  async getPost(id: number): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post || undefined;
  }

  async getPosts(limit = 10, offset = 0): Promise<Post[]> {
    return await db.select().from(posts).orderBy(desc(posts.createdAt)).limit(limit).offset(offset);
  }

  async getPostsByUser(userId: number, limit = 10, offset = 0): Promise<Post[]> {
    return await db.select().from(posts).where(eq(posts.authorId, userId)).orderBy(desc(posts.createdAt)).limit(limit).offset(offset);
  }

  async getFeedPosts(userId: number, limit = 10, offset = 0): Promise<Post[]> {
    // Get posts from followed users
    const followingUsers = await db.select({ id: follows.followingId }).from(follows).where(eq(follows.followerId, userId));
    const followingIds = followingUsers.map(f => f.id);
    
    if (followingIds.length === 0) {
      // If not following anyone, return recent posts
      return await this.getPosts(limit, offset);
    }

    // Include user's own posts and posts from followed users
    const allIds = [...followingIds, userId];
    return await db.select().from(posts).where(inArray(posts.authorId, allIds)).orderBy(desc(posts.createdAt)).limit(limit).offset(offset);
  }

  async deletePost(id: number, authorId: number): Promise<boolean> {
    const result = await db.delete(posts).where(and(eq(posts.id, id), eq(posts.authorId, authorId)));
    return result.rowCount > 0;
  }

  // Comment operations
  async createComment(comment: InsertComment, authorId: number): Promise<Comment> {
    const [newComment] = await db.insert(comments).values({ ...comment, authorId }).returning();
    return newComment;
  }

  async getCommentsByPost(postId: number): Promise<Comment[]> {
    return await db.select().from(comments).where(eq(comments.postId, postId)).orderBy(desc(comments.createdAt));
  }

  async deleteComment(id: number, authorId: number): Promise<boolean> {
    const result = await db.delete(comments).where(and(eq(comments.id, id), eq(comments.authorId, authorId)));
    return result.rowCount > 0;
  }

  // Like operations
  async toggleLike(postId: number, userId: number): Promise<boolean> {
    const existingLike = await db.select().from(likes).where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
    
    if (existingLike.length > 0) {
      // Unlike
      await db.delete(likes).where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
      return false;
    } else {
      // Like
      await db.insert(likes).values({ postId, userId });
      return true;
    }
  }

  async isPostLiked(postId: number, userId: number): Promise<boolean> {
    const [like] = await db.select().from(likes).where(and(eq(likes.postId, postId), eq(likes.userId, userId)));
    return !!like;
  }

  async getPostLikes(postId: number): Promise<number> {
    const [result] = await db.select({ count: count() }).from(likes).where(eq(likes.postId, postId));
    return result.count;
  }

  // Follow operations
  async followUser(followerId: number, followingId: number): Promise<boolean> {
    if (followerId === followingId) return false;
    
    const existingFollow = await db.select().from(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
    
    if (existingFollow.length === 0) {
      await db.insert(follows).values({ followerId, followingId });
      return true;
    }
    return false;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<boolean> {
    const result = await db.delete(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
    return result.rowCount > 0;
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const [follow] = await db.select().from(follows).where(and(eq(follows.followerId, followerId), eq(follows.followingId, followingId)));
    return !!follow;
  }

  async getFollowers(userId: number): Promise<User[]> {
    return await db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      password: users.password,
      name: users.name,
      bio: users.bio,
      avatar: users.avatar,
      createdAt: users.createdAt,
    }).from(follows).innerJoin(users, eq(follows.followerId, users.id)).where(eq(follows.followingId, userId));
  }

  async getFollowing(userId: number): Promise<User[]> {
    return await db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      password: users.password,
      name: users.name,
      bio: users.bio,
      avatar: users.avatar,
      createdAt: users.createdAt,
    }).from(follows).innerJoin(users, eq(follows.followingId, users.id)).where(eq(follows.followerId, userId));
  }

  async getFollowersCount(userId: number): Promise<number> {
    const [result] = await db.select({ count: count() }).from(follows).where(eq(follows.followingId, userId));
    return result.count;
  }

  async getFollowingCount(userId: number): Promise<number> {
    const [result] = await db.select({ count: count() }).from(follows).where(eq(follows.followerId, userId));
    return result.count;
  }

  async getSuggestedUsers(userId: number, limit = 5): Promise<User[]> {
    // Get users that the current user is not following
    const followingUsers = await db.select({ id: follows.followingId }).from(follows).where(eq(follows.followerId, userId));
    const followingIds = followingUsers.map(f => f.id);
    followingIds.push(userId); // Exclude self
    
    return await db.select().from(users).where(
      followingIds.length > 0 ? sql`${users.id} NOT IN (${followingIds.join(',')})` : sql`${users.id} != ${userId}`
    ).limit(limit);
  }
}

export const storage = new DatabaseStorage();
