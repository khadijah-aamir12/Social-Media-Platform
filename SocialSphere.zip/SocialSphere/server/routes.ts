import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema, insertFollowSchema } from "@shared/schema";
import { z } from "zod";

export function registerRoutes(app: Express): Server {
  // Authentication routes
  setupAuth(app);

  // Posts routes
  app.get("/api/posts", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;

      const posts = await storage.getPosts(limit, offset);
      
      // Get additional post data (author, likes, comments)
      const enrichedPosts = await Promise.all(
        posts.map(async (post) => {
          const author = await storage.getUser(post.authorId);
          const likesCount = await storage.getPostLikes(post.id);
          const comments = await storage.getCommentsByPost(post.id);
          const isLiked = req.user ? await storage.isPostLiked(post.id, req.user.id) : false;
          
          const enrichedComments = await Promise.all(
            comments.map(async (comment) => ({
              ...comment,
              author: await storage.getUser(comment.authorId),
            }))
          );

          return {
            ...post,
            author,
            likesCount,
            comments: enrichedComments,
            isLiked,
          };
        })
      );

      res.json(enrichedPosts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });

  app.get("/api/feed", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;

      const posts = await storage.getFeedPosts(req.user.id, limit, offset);
      
      // Get additional post data (author, likes, comments)
      const enrichedPosts = await Promise.all(
        posts.map(async (post) => {
          const author = await storage.getUser(post.authorId);
          const likesCount = await storage.getPostLikes(post.id);
          const comments = await storage.getCommentsByPost(post.id);
          const isLiked = await storage.isPostLiked(post.id, req.user.id);
          
          const enrichedComments = await Promise.all(
            comments.map(async (comment) => ({
              ...comment,
              author: await storage.getUser(comment.authorId),
            }))
          );

          return {
            ...post,
            author,
            likesCount,
            comments: enrichedComments,
            isLiked,
          };
        })
      );

      res.json(enrichedPosts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch feed" });
    }
  });

  app.post("/api/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const postData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(postData, req.user.id);
      
      const author = await storage.getUser(post.authorId);
      const likesCount = await storage.getPostLikes(post.id);
      
      res.status(201).json({
        ...post,
        author,
        likesCount,
        comments: [],
        isLiked: false,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid post data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create post" });
      }
    }
  });

  app.delete("/api/posts/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const postId = parseInt(req.params.id);
      const deleted = await storage.deletePost(postId, req.user.id);
      
      if (deleted) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Post not found or not authorized" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete post" });
    }
  });

  // Comments routes
  app.post("/api/posts/:id/comments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const postId = parseInt(req.params.id);
      const commentData = insertCommentSchema.parse({ ...req.body, postId });
      const comment = await storage.createComment(commentData, req.user.id);
      
      const author = await storage.getUser(comment.authorId);
      
      res.status(201).json({
        ...comment,
        author,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid comment data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create comment" });
      }
    }
  });

  // Likes routes
  app.post("/api/posts/:id/like", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const postId = parseInt(req.params.id);
      const isLiked = await storage.toggleLike(postId, req.user.id);
      const likesCount = await storage.getPostLikes(postId);
      
      res.json({ isLiked, likesCount });
    } catch (error) {
      res.status(500).json({ error: "Failed to toggle like" });
    }
  });

  // Follow routes
  app.post("/api/users/:id/follow", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const userId = parseInt(req.params.id);
      const followed = await storage.followUser(req.user.id, userId);
      
      res.json({ followed });
    } catch (error) {
      res.status(500).json({ error: "Failed to follow user" });
    }
  });

  app.delete("/api/users/:id/follow", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const userId = parseInt(req.params.id);
      const unfollowed = await storage.unfollowUser(req.user.id, userId);
      
      res.json({ unfollowed });
    } catch (error) {
      res.status(500).json({ error: "Failed to unfollow user" });
    }
  });

  // User profile routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const followersCount = await storage.getFollowersCount(userId);
      const followingCount = await storage.getFollowingCount(userId);
      const posts = await storage.getPostsByUser(userId, 10, 0);
      const isFollowing = req.user ? await storage.isFollowing(req.user.id, userId) : false;
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json({
        ...userWithoutPassword,
        followersCount,
        followingCount,
        postsCount: posts.length,
        isFollowing,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user profile" });
    }
  });

  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = (page - 1) * limit;

      const posts = await storage.getPostsByUser(userId, limit, offset);
      
      // Get additional post data
      const enrichedPosts = await Promise.all(
        posts.map(async (post) => {
          const author = await storage.getUser(post.authorId);
          const likesCount = await storage.getPostLikes(post.id);
          const comments = await storage.getCommentsByPost(post.id);
          const isLiked = req.user ? await storage.isPostLiked(post.id, req.user.id) : false;
          
          const enrichedComments = await Promise.all(
            comments.map(async (comment) => ({
              ...comment,
              author: await storage.getUser(comment.authorId),
            }))
          );

          return {
            ...post,
            author,
            likesCount,
            comments: enrichedComments,
            isLiked,
          };
        })
      );

      res.json(enrichedPosts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user posts" });
    }
  });

  // Search routes
  app.get("/api/search/users", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.json([]);
      }

      const users = await storage.searchUsers(query);
      
      // Remove passwords from response
      const safeUsers = users.map(({ password, ...user }) => user);
      
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to search users" });
    }
  });

  // Suggested users
  app.get("/api/suggested-users", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }

    try {
      const users = await storage.getSuggestedUsers(req.user.id, 5);
      
      // Remove passwords from response
      const safeUsers = users.map(({ password, ...user }) => user);
      
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suggested users" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
