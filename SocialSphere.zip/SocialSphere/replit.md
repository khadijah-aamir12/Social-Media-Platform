# Social Media Platform

## Overview

This is a modern social media platform built with React and Express.js, featuring a clean Twitter-like interface for users to share posts, interact with content, and connect with others. The application uses a full-stack TypeScript setup with Drizzle ORM for database operations and shadcn/ui for the component library.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with a clear separation between client and server code:

- **Frontend**: React with TypeScript, Vite for development and building
- **Backend**: Express.js with TypeScript, using ESM modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Styling**: Tailwind CSS with shadcn/ui components
- **Authentication**: Session-based authentication with Passport.js
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **React Router**: Uses wouter for client-side routing
- **State Management**: TanStack Query for server state, React Context for authentication
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Express.js**: RESTful API server with middleware for logging and error handling
- **Authentication**: Passport.js with local strategy, bcrypt-style password hashing
- **Session Management**: Express sessions with PostgreSQL store
- **Database**: Drizzle ORM with PostgreSQL, using Neon serverless for cloud deployment
- **Validation**: Zod schemas shared between client and server

### Database Schema
The application uses five main tables:
- **users**: User accounts with authentication credentials and profile information
- **posts**: User-generated content with optional image attachments
- **comments**: Threaded comments on posts
- **likes**: User reactions to posts
- **follows**: User-to-user following relationships

## Data Flow

1. **Authentication Flow**: Users log in through the frontend, which sends credentials to the backend. The server validates credentials and creates a session.

2. **Post Creation**: Users create posts through a modal interface. The frontend sends post data to the API, which validates and stores it in the database.

3. **Feed Generation**: The home page displays a personalized feed by fetching posts from followed users, along with engagement data (likes, comments).

4. **Real-time Updates**: The application uses TanStack Query's invalidation system to update the UI when data changes, providing a responsive user experience.

## External Dependencies

### Frontend Dependencies
- **React & React DOM**: Core framework
- **TanStack Query**: Server state management
- **wouter**: Lightweight routing
- **React Hook Form**: Form management
- **Zod**: Schema validation
- **date-fns**: Date manipulation
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling

### Backend Dependencies
- **Express.js**: Web framework
- **Passport.js**: Authentication middleware
- **Drizzle ORM**: Database toolkit
- **@neondatabase/serverless**: PostgreSQL driver for Neon
- **connect-pg-simple**: PostgreSQL session store
- **express-session**: Session middleware

### Development Dependencies
- **Vite**: Development server and build tool
- **TypeScript**: Type checking
- **ESBuild**: Server bundling
- **tsx**: TypeScript execution for development

## Deployment Strategy

The application is configured for Replit deployment:

1. **Development**: Uses Vite dev server with HMR and error overlays
2. **Production Build**: 
   - Frontend: Vite builds static assets to `dist/public`
   - Backend: ESBuild bundles server code to `dist/index.js`
3. **Environment Variables**: Requires `DATABASE_URL` and `SESSION_SECRET`
4. **Database**: Uses Neon serverless PostgreSQL with connection pooling
5. **Static Files**: Express serves built frontend assets in production

The build process creates a single production bundle that can be deployed to any Node.js hosting platform, with special optimizations for the Replit environment including development banners and cartographer integration.