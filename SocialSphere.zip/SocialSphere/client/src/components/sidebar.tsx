import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CreatePostModal } from "./create-post-modal";
import { Plus, UserPlus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function Sidebar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: suggestedUsers } = useQuery({
    queryKey: ["/api/suggested-users"],
    enabled: !!user,
  });

  const followMutation = useMutation({
    mutationFn: async (userId: number) => {
      return await apiRequest("POST", `/api/users/${userId}/follow`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggested-users"] });
      toast({
        title: "Success",
        description: "You are now following this user",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* User Profile Card */}
      <Card>
        <CardContent className="p-6">
          <Link href={`/profile/${user.id}`} className="flex items-center space-x-3 mb-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>
                {user.name.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold">{user.name}</h3>
              <p className="text-sm text-gray-500">@{user.username}</p>
            </div>
          </Link>
          
          <div className="grid grid-cols-3 gap-4 mb-4 text-center">
            <div>
              <div className="font-semibold">127</div>
              <div className="text-xs text-gray-500">Posts</div>
            </div>
            <div>
              <div className="font-semibold">2.1K</div>
              <div className="text-xs text-gray-500">Followers</div>
            </div>
            <div>
              <div className="font-semibold">845</div>
              <div className="text-xs text-gray-500">Following</div>
            </div>
          </div>
          
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Post
          </Button>
        </CardContent>
      </Card>

      {/* Suggested Users */}
      {suggestedUsers && suggestedUsers.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Suggested for you</h3>
            <div className="space-y-3">
              {suggestedUsers.map((suggestedUser: any) => (
                <div key={suggestedUser.id} className="flex items-center justify-between">
                  <Link href={`/profile/${suggestedUser.id}`} className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={suggestedUser.avatar} alt={suggestedUser.name} />
                      <AvatarFallback>
                        {suggestedUser.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{suggestedUser.name}</p>
                      <p className="text-xs text-gray-500">@{suggestedUser.username}</p>
                    </div>
                  </Link>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => followMutation.mutate(suggestedUser.id)}
                    disabled={followMutation.isPending}
                  >
                    <UserPlus className="h-3 w-3 mr-1" />
                    Follow
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <CreatePostModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />
    </div>
  );
}
