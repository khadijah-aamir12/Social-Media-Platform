import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { Sidebar } from "@/components/sidebar";
import { PostCard } from "@/components/post-card";
import { CreatePostModal } from "@/components/create-post-modal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export default function HomePage() {
  const { user } = useAuth();
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: posts, isLoading, error } = useQuery({
    queryKey: ["/api/feed"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center min-h-[50vh]">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p className="text-red-500">Failed to load posts. Please try again.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="hidden lg:block">
            <Sidebar />
          </div>

          {/* Main Feed */}
          <div className="lg:col-span-2">
            <div className="max-w-2xl mx-auto space-y-6">
              {/* Create Post Button - Mobile */}
              <Card className="lg:hidden">
                <CardContent className="p-4">
                  <Button
                    onClick={() => setShowCreateModal(true)}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    What's on your mind?
                  </Button>
                </CardContent>
              </Card>

              {/* Posts */}
              {posts && posts.length > 0 ? (
                posts.map((post: any) => (
                  <PostCard key={post.id} post={post} />
                ))
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500">No posts to show yet.</p>
                    <p className="text-sm text-gray-400 mt-2">
                      Follow some users or create your first post!
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="hidden lg:block">
            <div className="space-y-6">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-4">Trending Topics</h3>
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2">
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        #TechNews
                      </span>
                      <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-sm">
                        #Photography
                      </span>
                      <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                        #Travel
                      </span>
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                        #Fitness
                      </span>
                      <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                        #Coding
                      </span>
                      <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-sm">
                        #Food
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-4">Recent Activity</h3>
                  <div className="space-y-3 text-sm text-gray-600">
                    <p>
                      <span className="font-medium">Sarah Wilson</span> liked your post
                    </p>
                    <p>
                      <span className="font-medium">Mike Johnson</span> started following you
                    </p>
                    <p>
                      <span className="font-medium">Emma Davis</span> commented on your post
                    </p>
                    <p>
                      <span className="font-medium">Alex Rivera</span> shared your post
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <CreatePostModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />
    </div>
  );
}
